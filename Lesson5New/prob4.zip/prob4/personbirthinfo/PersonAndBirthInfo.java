package lesson5.labs.prob4.personbirthinfo;

public interface PersonAndBirthInfo {
	public Person getPerson();
	public BirthInfo getBirthInfo();
}
