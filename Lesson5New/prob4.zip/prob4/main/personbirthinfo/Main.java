package lesson5.labs.prob4.main.personbirthinfo;
import java.util.*;

import lesson5.labs.prob4.personbirthinfo.Person;
import lesson5.labs.prob4.personbirthinfo.PersonAndBirthInfo;
import lesson5.labs.prob4.personbirthinfo.PersonBirthInfoFactory;
import lesson5.labs.prob4.personbirthinfo.BirthInfo;
import lesson5.labs.prob4.data.personbirthinfo.Database;
import lesson5.labs.prob4.data.personbirthinfo.DataRecord;


public class Main {

	public static void main(String[] args) 
	{
		//two setters
		printTopStudents();
		
			
		
	}
	public static void printTopStudents() 
	{
		Collection<DataRecord> data = Database.h.values();
		List<BirthInfo> lstBirthInfo = new ArrayList<>();
		for(DataRecord d : data) 
		{
			PersonAndBirthInfo pb = PersonBirthInfoFactory.createPersonAndBirthInfo(d.getName(), d.getDateOfBirth());
			lstBirthInfo.add(pb.getBirthInfo());	
		}
		
		//Collections.sort(reports);
		/*Iterator<BirthInfo> it = lstBirthInfo.iterator();
		//System.out.println("A Students:");
		BirthInfo next = null;
		while((next =it.next()) != null ) {
			System.out.println(next.getPerson().getName() + " ");
		}
		*/
		
		for(BirthInfo b : lstBirthInfo)
		{
			System.out.println(b.getPerson().getName() + "\t"+ b.getDateOfBirth());
		}
	}
	

}
